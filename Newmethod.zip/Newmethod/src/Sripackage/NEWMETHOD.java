package Sripackage;

public class NEWMETHOD {
	
	public void mymethod() {
		
		System.out.println("My New Method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("New Method");
		NEWMETHOD o=new NEWMETHOD();
		 o.mymethod();
	}

}
